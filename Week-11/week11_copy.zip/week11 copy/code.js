function changeImage() {
    var image = document.getElementById('myImage');
    if (image.src.match("bmwhite.jpg")) {
        image.src = "bmwhite.jpg";
    }
    else {
        image.src = "bmwhite.jpg";
    }
}
function changeImageBlack() {
    var image = document.getElementById('myImage');
    if (image.src.match("bmwhite.jpg")) {
        image.src = "bmblack.jpg";
    }
    else {
        image.src = "bmblack.jpg";
    }
}
function changeImageGray() {
    var image = document.getElementById('myImage');
    if (image.src.match("bmwhite.jpg")) {
        image.src = "bmgray.jpg";
    }
    else {
        image.src = "bmgray.jpg";
    }
}
function changeImageCaro() {
    var image = document.getElementById('myImage');
    if (image.src.match("bmwhite.jpg")) {
        image.src = "bmcarolina.jpg";
    }
    else {
        image.src = "bmcarolina.jpg";
    }
}
function changeImageNavy() {
    var image = document.getElementById('myImage');
    if (image.src.match("bmwhite.jpg")) {
        image.src = "bmnavy.jpg";
    }
    else {
        image.src = "bmnavy.jpg";
    }
}
function changeImageViolet() {
    var image = document.getElementById('myImage');
    if (image.src.match("bmwhite.jpg")) {
        image.src = "bmviolet.jpg";
    }
    else {
        image.src = "bmviolet.jpg";;
    }
}
function changeImageOrange() {
    var image = document.getElementById('myImage');
    if (image.src.match("bmwhite.jpg")) {
        image.src = "bmorange.jpg";
    }
    else {
        image.src = "bmorange.jpg";
    }
}
function changeImageRed() {
    var image = document.getElementById('myImage');
    if (image.src.match("bmwhite.jpg")) {
        image.src = "bmred.jpg";
    }
    else {
        image.src = "bmred.jpg";
    }
}

function changeAccent() {
    var image = document.getElementById('myAccent');
    if (image.src.match("bablack.png")) {
        image.src = "bawhite.png";
    }
    else {
        image.src = "bawhite.png";
    }
 }
 function changeAccentBlack() {
    var image = document.getElementById('myAccent');
    if (image.src.match("bablack.png")) {
        image.src = "bablack.png";
    }
    else {
        image.src = "bablack.png";
    }
 }
 function changeAccentGray() {
    var image = document.getElementById('myAccent');
    if (image.src.match("bablack.png")) {
        image.src = "bagray.png";
    }
    else {
        image.src = "bagray.png";
    }
 }
 function changeAccentCaro() {
    var image = document.getElementById('myAccent');
    if (image.src.match("bablack.png")) {
        image.src = "bacarolina.png";
    }
    else {
        image.src = "bacarolina.png";
    }
 }
 function changeAccentNavy() {
    var image = document.getElementById('myAccent');
    if (image.src.match("bablack.png")) {
        image.src = "banavy.png";
    }
    else {
        image.src = "banavy.png";
    }
 }
 function changeAccentViolet() {
    var image = document.getElementById('myAccent');
    if (image.src.match("bablack.png")) {
        image.src = "baviolet.png";
    }
    else {
        image.src = "baviolet.png";;
    }
 }
 function changeAccentOrange() {
    var image = document.getElementById('myAccent');
    if (image.src.match("bablack.png")) {
        image.src = "baorange.png";
    }
    else {
        image.src = "baorange.png";
    }
 }
 function changeAccentRed() {
    var image = document.getElementById('myAccent');
    if (image.src.match("bablack.png")) {
        image.src = "bared.png";
    }
    else {
        image.src = "bared.png";
    }
 }
 